package wXoJavaModel;

public enum WarrantyTypes {
	Basic,
	Extended,
	Lifetime,
	Limited_lifetime;
}
