package wXoJavaModel;

public enum Acceptance {
Accepted, Rejected;
}
