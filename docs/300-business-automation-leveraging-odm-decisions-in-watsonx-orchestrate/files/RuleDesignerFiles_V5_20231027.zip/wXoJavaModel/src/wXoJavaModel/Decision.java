package wXoJavaModel;

import java.util.Date;
import java.time.LocalDate;
import java.time.ZoneId;


public class Decision {
	Acceptance returnStatus;
	Float refundAmount;
	String comments;
	Float fee;
	ActionType action;
	Date requestDate;

	public Decision() {
		super();
		LocalDate today = LocalDate.now();

		this.requestDate = localDateToDate(today);
	}

	public Decision(Acceptance returnStatus, Float refundAmount, String comments, Float fee, ActionType action,
			Date requestDate) {
		super();
		this.returnStatus = returnStatus;
		this.refundAmount = refundAmount;
		this.comments = comments;
		this.fee = fee;
		this.action = action;
		this.requestDate = requestDate;
	}

	public Float getRefundAmount() {
		return refundAmount;
	}

	public Acceptance getReturnStatus() {
		return returnStatus;
	}

	public void setReturnStatus(Acceptance returnDecision) {
		this.returnStatus = returnDecision;
	}

	public void setRefundAmount(Float refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Float getFee() {
		return fee;
	}

	public void setFee(Float fee) {
		this.fee = fee;
	}

	public ActionType getAction() {
		return action;
	}

	public void setAction(ActionType action) {
		this.action = action;
	}
	
	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}
	
	public String printRequestDate() {
		return requestDate.toString();
	}


	public void print() {
		System.out.println("--------------------- RETURN DECISION ------------------------");
		System.out.println("The request date is " + this.requestDate);
		System.out.println("The decision is " + this.returnStatus );
		System.out.println("   - Commment: " + this.comments);
		System.out.println("Return details: ");
		System.out.println("  - Return  fee: " + this.fee );
		System.out.println("  - Refund amount: " + this.refundAmount);
		System.out.println("  - Next action: " + this.action);
	}



	private Date localDateToDate(LocalDate lDate) {
		ZoneId defaultZoneId = ZoneId.systemDefault();
		return Date.from(lDate.atStartOfDay(defaultZoneId).toInstant());

	}
}
