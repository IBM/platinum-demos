package wXoJavaModel;

import java.util.Date;
import java.time.LocalDate ;
import java.time.temporal.ChronoUnit;
import java.time.ZoneId;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Customer {
	String name;
	Country country;
	Integer yearsAsCustomer;
	Loyalty loyaltyLevel;
	Integer numberOfPurchases;
	Integer numberOfClaimsInLastHalf;
	Date LastReturnDate;
	
	
	public Customer() {
		super();
		this.name = "Dupont";
		this.country = Country.USA;
		this.yearsAsCustomer = 1;
		this.loyaltyLevel = Loyalty.Gold;
		this.numberOfPurchases = 10;
		this.numberOfClaimsInLastHalf = 10;
		this.LastReturnDate = stringToDate("2023-10-05");	
	}

	public Customer(String name, Country country, Integer yearsAsCustomer, Loyalty loyaltyLevel,
			Integer numberOfPurchases, Integer numberOfClaimsInLastHalf, Date lastReturnDate) {
		super();
		this.name = name;
		this.country = country;
		this.yearsAsCustomer = yearsAsCustomer;
		this.loyaltyLevel = loyaltyLevel;
		this.numberOfPurchases = numberOfPurchases;
		this.numberOfClaimsInLastHalf = numberOfClaimsInLastHalf;
		this.LastReturnDate = lastReturnDate;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Country getCountry() {
		return country;
	}
	public void setCountry(Country country) {
		this.country = country;
	}
	public Integer getYearsAsCustomer() {
		return yearsAsCustomer;
	}
	public void setYearsAsCustomer(Integer yearsOfCustomer) {
		this.yearsAsCustomer = yearsOfCustomer;
	}
	public Loyalty getLoyaltyLevel() {
		return loyaltyLevel;
	}
	public void setLoyaltyLevel(Loyalty loyaltyLevel) {
		this.loyaltyLevel = loyaltyLevel;
	}
	public Integer getNumberOfPurchases() {
		return numberOfPurchases;
	}
	public void setNumberOfPurchases(Integer numberOfPurchases) {
		this.numberOfPurchases = numberOfPurchases;
	}
	public Integer getNumberOfClaimsInLastHalf() {
		return numberOfClaimsInLastHalf;
	}
	public void setNumberOfClaimsInLastHalf(Integer numberOfClaimsInLastHalf) {
		this.numberOfClaimsInLastHalf = numberOfClaimsInLastHalf;
	}
	public Date getLastReturnDate() {
		return LastReturnDate;
	}
	public void setLastReturnDate(Date lastReturnDate) {
		LastReturnDate = lastReturnDate;
	}
	
	public long numberOfDaysSinceLastReturn() {
		LocalDate today = LocalDate.now();
		LocalDate returnDate   = convertToLocalDate(this.LastReturnDate);

		long diffInDays = ChronoUnit.DAYS.between(returnDate, today);
		return diffInDays;
	}
	
	public String printLastReturnDate() {
		return LastReturnDate.toString();
	}
	
	LocalDate convertToLocalDate(Date dateToConvert) {
	    return dateToConvert.toInstant()
	      .atZone(ZoneId.systemDefault())
	      .toLocalDate();
	}
	
	public static Date stringToDate(String dateVlaue) {
	    Date date = null;
	    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

	    try {

	        date = formatter.parse(dateVlaue);

	    } catch (ParseException e) {
	        e.printStackTrace();
	    }
	    return date;
	}
	
	public void printDetails() {
		
		System.out.println("----------------------------------------------------------------");
		System.out.println("Customer details:");
		System.out.println("  - Name: "+ this.name);
		System.out.println("  - Country: "+ this.country);
		System.out.println("  - Years as customer: "+ this.yearsAsCustomer);
		System.out.println("  - Loyalty: "+ this.loyaltyLevel);
		System.out.println("  - Nb purchase: "+ this.numberOfPurchases);
		System.out.println("  - Nb claims: "+ this.numberOfClaimsInLastHalf);		
		System.out.println("  - Last return date: "+ this.LastReturnDate.toString());
		System.out.println("----------------------------------------------------------------");
	}
}

